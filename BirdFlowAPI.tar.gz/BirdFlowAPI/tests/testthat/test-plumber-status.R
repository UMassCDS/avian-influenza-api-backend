test_that("example API test", {
  expect_silent({
    # Start plumber API
    local_api <- callthat::call_that_plumber_start(api_folder = system.file("plumber", "flow", "endpoints", package = "BirdFlowAPI"), api_file = "status.R")
    # Start test session
    api_session <- callthat::call_that_session_start(local_api)
  })

  # Make API call
  get_predict <- callthat::call_that_api_get(api_session, endpoint = "status", query = NULL)
  expect_s3_class(get_predict, "response")

  # Run tests on response
  expect_equal(get_predict$status_code, 200)

  # Test to confirm the output of the API is correct
  content <- httr::content(get_predict)[[1]][[1]]
  expect_equal(content, "API is running fine!")

  # Close session and plumber API
  expect_null(callthat::call_that_session_stop(api_session))
  expect_null(callthat::call_that_plumber_stop(api_session))
})
