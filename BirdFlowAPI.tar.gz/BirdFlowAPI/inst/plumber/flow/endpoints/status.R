#* @get /status
function() {
  list(status = "API is running fine!")
}